resource "aws_s3_bucket" "public_assets" {
  bucket = "hosted-iac-policy-scan-public-assets"
  acl    = "public-read"
}
